package stepdefinition;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.PersonalDetailsPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonaldetailsStep {
	WebDriver webDriver;
	PersonalDetailsPage personaldetailspage;
	
	@Before
	public void setup() {
		webDriver=BrowserFactory.startBrowser("chrome", "C://Users//nandaac//Desktop//mod%204%20%20desk//Module4Example//src//test//java//Html//PersonalDetails.html");
	}
	@After
	public void tearDown() {
		webDriver.close();
	}
	
	@Given("^User is on Personal Details page$")
	public void user_is_on_Personal_Details_page() throws Throwable {
		personaldetailspage=PageFactory.initElements(webDriver, PersonalDetailsPage.class);  
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("Personal Details", webDriver.getTitle()); 
		  if(webDriver.getTitle().equals("Personal Details")) {
			  System.out.println("Title is matched");
		  }
		  else {
			  System.out.println("Not Matched");
			  webDriver.quit();
		  }
	}

@Then("^Verify the textname on the page$")
public void verify_the_textname_on_the_page() throws Throwable {
	assertEquals("Step 1: Personal Details", personaldetailspage.textname()); 
	  if(personaldetailspage.textname().equals("Step 1: Personal Details")) {
		  System.out.println("Text is matched");
	  }
	  else {
		  System.out.println("Text is not found on page");
}}


	@When("^User leaves First Name empty$")
	public void user_leaves_First_Name_empty() throws Throwable {
		personaldetailspage.setFirstname("");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}

	@Then("^Display First Name Alert msg$")
	public void display_First_Name_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the First Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Last Name empty$")
	public void user_leaves_Last_Name_empty() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}
	

	@Then("^Display Last Name Alert msg$")
	public void display_Last_Name_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Last Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Email empty$")
	public void user_leaves_Email_empty() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}

	@Then("^Display Email Alert msg$")
	public void display_Email_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User enters incorrect Email format and clicks the Next link$")
	public void user_enters_incorrect_Email_format_and_clicks_the_Next_link(DataTable arg1) throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			personaldetailspage.setEmail(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", objlist.get(i))) {
				System.out.println("**VAlid email -Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		personaldetailspage.clickingnextlink();
	}

	@When("^User leaves Contact no empty$")
	public void user_leaves_Contact_no_empty() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
	}

	@Then("^Display Contact no Alert msg$")
	public void display_Contact_no_Alert_msg() throws Throwable {
		try {
			Alert alt = webDriver.switchTo().alert();
			webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
			String msg = alt.getText();
			if (msg.equals("Please fill the Contact No.")) {
				System.out.println("The text msg on alert box is: " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("^User enters incorrect Contact no  and clicks the Next link$")
	public void user_enters_incorrect_Contact_no_and_clicks_the_Next_link(DataTable arg1) throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
	
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			personaldetailspage.setContactno(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[7-9]{1}[0-9]{9}", objlist.get(i))) {
				System.out.println("**VAlid mobile no--Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		personaldetailspage.clickingnextlink();
	}

	@When("^User leaves address line (\\d+) empty$")
	public void user_leaves_address_line_empty(int arg1) throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}
	

	@Then("^Display address line (\\d+) Alert msg$")
	public void display_address_line_Alert_msg(int arg1) throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the address line 1")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	@When("^User leaves Address Line (\\d+) empty$")
	public void user_leaves_Address_Line_empty(int arg1) throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}

	@Then("^Display Address Line (\\d+) Alert msg$")
	public void display_Address_Line_Alert_msg(int arg1) throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the address line 2")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	@When("^User leaves City empty$")
	public void user_leaves_City_empty() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}

	@Then("^Display City Alert msg$")
	public void display_City_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves State empty$")
	public void user_leaves_State_empty() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("");
		personaldetailspage.clickingnextlink();
	}

	@Then("^Display State Alert msg$")
	public void display_State_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select state")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@Given("^Display valid Alert msg$")
	public void display_valid_Alert_msg() throws Throwable {
		personaldetailspage.setFirstname("George");
		personaldetailspage.setLastname("John");
		personaldetailspage.setEmail("john@gmail.com");
		personaldetailspage.setContactno("7418935662");
		personaldetailspage.setAddress1("Califonia");
		personaldetailspage.setAddress2("beml");
		personaldetailspage.setCity("SanDiego");
		personaldetailspage.setState("Sacramento");
		personaldetailspage.clickingnextlink();
	}
	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
	    System.out.println("succesfful");
	}
}
