package stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;

import com.cg.page.employeedetailspage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class employeedetailsstep {
	WebDriver webDriver;
	employeedetailspage page;
	
	@Before
	public void setup() {
		webDriver=BrowserFactory.startBrowser("chrome", "C://Users//nandaac//Desktop//mod%204%20%20desk//Module4Example//src//test//java//Html//EducationalDetails.html");
	}
	@After
	public void tearDown() {
		webDriver.close();
	}
	@Given("^User is on Educational Details page$")
	public void user_is_on_Educational_Details_page() throws Throwable {
		page=PageFactory.initElements(webDriver, employeedetailspage.class);  
	}

	@Then("^Verify the titlee of the page$")
	public void verify_the_titlee_of_the_page() throws Throwable {
		assertEquals("Educational Details", webDriver.getTitle()); 
		  if(webDriver.getTitle().equals("Educational Details")) {
			  System.out.println("Title is matched");
		  }
		  else {
			  System.out.println("Not Matched");
			  webDriver.quit();
		  }
	}

	@Then("^Verify the textnamee on the page$")
	public void verify_the_textnamee_on_the_page() throws Throwable {
		assertEquals("Step 2: Educational Details", page.textnamee()); 
		  if(page.textnamee().equals("Step 2: Educational Details")) {
			  System.out.println("Text is matched");
		  }
		  else {
			  System.out.println("Text is not found on page");
	}}
	

	@When("^User leaves Graduation empty$")
	public void user_leaves_Graduation_empty() throws Throwable {
		page.setGraduation("");
		page.setPercentage("74");
		page.setPassingYear("2018");
		page.setProjectName("Network");
		page.setTechnologiesused("java");
		page.setOthertechnologies("spring");
		page.register();
	}

	@Then("^Display Graduation Alert msg$")
	public void display_Graduation_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please Select Graduation")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();  
	}

	@When("^User leaves Percentage empty$")
	public void user_leaves_Percentage_empty() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("");
		page.setPassingYear("2018");
		page.setProjectName("Network");
		page.setTechnologiesused("java");
		page.setOthertechnologies("spring");
		page.register();
	}

	@Then("^Display Percentage Alert msg$")
	public void display_Percentage_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill Percentage detail")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept(); 
	}

	@When("^User leaves PassingYear empty$")
	public void user_leaves_PassingYear_empty() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("74");
		page.setPassingYear("");
		page.setProjectName("Network");
		page.setTechnologiesused("java");
		page.setOthertechnologies("spring");
		page.register();   
	}
	@Then("^Display PassingYear Alert msg$")
	public void display_PassingYear_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill Passing Year")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves projectName empty$")
	public void user_leaves_projectName_empty() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("74");
		page.setPassingYear("2018");
		page.setProjectName("");
		page.setTechnologiesused("java");
		page.setOthertechnologies("spring");
		page.register();
	}

	@Then("^Display projectName Alert msg$")
	public void display_projectName_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill Project Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Technologies used empty$")
	public void user_leaves_Technologies_used_empty() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("74");
		page.setPassingYear("2018");
		page.setProjectName("Network");
		page.setTechnologiesused("");
		page.setOthertechnologies("spring");
		page.register();
	}

	@Then("^Display Technologies used Alert msg$")
	public void display_Technologies_used_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please Select Technologies Used")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves other technologies empty$")
	public void user_leaves_other_technologies_empty() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("74");
		page.setPassingYear("2018");
		page.setProjectName("Network");
		page.setTechnologiesused("java");
		page.setOthertechnologies("");
		page.register(); 
	}

	@Then("^Display other technologies Alert msg$")
	public void display_other_technologies_Alert_msg() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill other Technologies Used")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	
	@Then("^Display valid Alert msg$")
	public void display_valid_Alert_msg() throws Throwable {
		page.setGraduation("B.E.");
		page.setPercentage("74");
		page.setPassingYear("2018");
		page.setProjectName("Network");
		page.setTechnologiesused("java");
		page.setOthertechnologies("Spring");
		page.register(); 
	}
}

