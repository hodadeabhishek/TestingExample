package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PersonalDetailsPage {
	WebDriver webDriver;
	
	private WebElement title;
	
	@FindBy(how=How.XPATH, using="/html/body/h4" )
	@CacheLookup
	private WebElement textname;
	
	@FindBy(how = How.NAME, using = "txtFN")
	@CacheLookup
	private WebElement firstname;

	@FindBy(how = How.ID, using = "txtLastName")
	@CacheLookup
	private WebElement lastname;

	@FindBy(how = How.NAME, using = "Email")
	@CacheLookup
	private WebElement email;

	@FindBy(how = How.ID, using = "txtPhone")
	@CacheLookup
	private WebElement contactno;

	@FindBy(how = How.NAME, using = "address1")
	@CacheLookup
	private WebElement address1;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"txtAddress2\"]")
	@CacheLookup
	private WebElement address2;

	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	private WebElement city;

	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	private WebElement state;

	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	private WebElement nextlink;

	public PersonalDetailsPage() {
		super();
	}
	public PersonalDetailsPage(WebDriver webDriver) {
		super();
		this.webDriver = webDriver;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno.sendKeys(contactno);
	}

	public WebElement getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public WebElement getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String titlename() {
		 return webDriver.getTitle();
		}
	public String textname() {
		 return this.textname.getText();
		}
	
	public void clickingnextlink() {
		this.nextlink.click();
	}
	
}
