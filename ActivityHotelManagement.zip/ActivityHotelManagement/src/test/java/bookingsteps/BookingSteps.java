package bookingsteps;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.BookingPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingSteps {

	WebDriver driver;
	
	BookingPage page;
	
	@Before
	public void setUp() {

		driver = BrowserFactory.startBrowser("chrome",
				"file:///C:/Users/nandaac/Desktop/mod%204%20%20desk/ActivityHotelManagement/src/test/java/html/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}
	
	@Given("^User is on Welcome to HotelbookingPage page$")
	public void user_is_on_Welcome_to_HotelbookingPage_page() throws Throwable {
		page = PageFactory.initElements(driver, BookingPage.class);
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("Hotel Booking", driver.getTitle());
		if (driver.getTitle().equals("Hotel Booking")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^User leaves Firstname empty$")
	public void user_leaves_Firstname_empty() throws Throwable {
		page.setFirstname("");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display Firstname Alert msg$")
	public void display_Firstname_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the First Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Lastname empty$")
	public void user_leaves_Lastname_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display Lastname Alert msg$")
	public void display_Lastname_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();

		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Last Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Email empty$")
	public void user_leaves_Email_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}
	
	@Then("^Display Email Alert msg$")
	public void display_Email_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	
	@When("^Customer enters incorrect Email format and clicks the place order button$")
	public void customer_enters_incorrect_Email_format_and_clicks_the_place_order_button(DataTable arg1) throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			page.setEmail(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", objlist.get(i))) {
				System.out.println("**VAlid email -Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		page.Confirmbooking();
	}

	@When("^User leaves Mobileno empty$")
	public void user_leaves_Mobileno_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display Mobileno Alert msg$")
	public void display_Mobileno_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Mobile No.")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Customer enters incorrect mobileNo format and clicks the place order button$")
	public void customer_enters_incorrect_mobileNo_format_and_clicks_the_place_order_button(DataTable arg1) throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			page.setMobileno(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[7-9]{1}[0-9]{9}", objlist.get(i))) {
				System.out.println("**VAlid mobile no--Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		page.Confirmbooking();
	}



	@When("^User leaves City empty$")
	public void user_leaves_City_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("BEML");
		page.setCity("");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display City Alert msg$")
	public void display_City_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves State empty$")
	public void user_leaves_State_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display State Alert msg$")
	public void display_State_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select state")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves CardHolderName empty$")
	public void user_leaves_CardHolderName_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display CardHolderName Alert msg$")
	public void display_CardHolderName_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Card holder name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves DebitCardNumber empty$")
	public void user_leaves_DebitCardNumber_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display DebitCardNumber Alert msg$")
	public void display_DebitCardNumber_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Debit card Number")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves CardExpirationMonth empty$")
	public void user_leaves_CardExpirationMonth_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Display CardExpirationMonth Alert msg$")
	public void display_CardExpirationMonth_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill expiration month")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves CardExpirationYear empty$")
	public void user_leaves_CardExpirationYear_empty() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("");
		page.Confirmbooking();
	}

	@Then("^Display CardExpirationYear Alert msg$")
	public void display_CardExpirationYear_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the expiration year")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User enters All Details correct$")
	public void user_enters_All_Details_correct() throws Throwable {
		page.setFirstname("Cap");
		page.setLastname("Gemini");
		page.setEmail("cap@gmail.com");
		page.setMobileno("7998935662");
		page.setAddress("MIPL");
		page.setCity("Chennai");
		page.setState("Tamilnadu");
		page.setNoofpeople("3");
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
	}

	@Then("^Navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		Thread.sleep(1000);
		driver.navigate().to("file:///C:/Users/nandaac/Desktop/mod%204%20%20desk/ActivityHotelManagement/src/test/java/html/success.html");
	}


}
