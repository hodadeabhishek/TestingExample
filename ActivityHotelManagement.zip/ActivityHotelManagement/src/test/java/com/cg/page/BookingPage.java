package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookingPage {

	WebDriver driver;

	@FindBy(how = How.ID, using = "txtFirstName")
	@CacheLookup
	private WebElement firstname;

	@FindBy(how = How.ID, using = "txtLastName")
	@CacheLookup
	private WebElement lastname;

	@FindBy(how = How.NAME, using = "Email")
	@CacheLookup
	private WebElement email;

	@FindBy(how = How.NAME, using = "Phone")
	@CacheLookup
	private WebElement mobileno;

	@FindBy(how = How.XPATH, using = "/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	private WebElement address;

	@FindBy(how = How.XPATH, using = "/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	private WebElement Noofpeople;

	@FindBy(how = How.XPATH, using = "/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	private WebElement city;

	@FindBy(how = How.XPATH, using = "/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	private WebElement state;

	@FindBy(how = How.ID, using = "txtCardholderName")
	@CacheLookup
	private WebElement cardholdername;

	@FindBy(how = How.ID, using = "txtDebit")
	@CacheLookup
	private WebElement debitcardno;

	@FindBy(how = How.ID, using = "txtCvv")
	@CacheLookup
	private WebElement CVV;

	@FindBy(how = How.NAME, using = "month")
	@CacheLookup
	private WebElement expirymonth;

	@FindBy(how = How.NAME, using = "year")
	@CacheLookup
	private WebElement expiryyear;

	@FindBy(how = How.XPATH, using = "//*[@id=\"btnPayment\"]")
	@CacheLookup
	private WebElement confirmbooking;

	public BookingPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno.sendKeys(mobileno);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getNoofpeople() {
		return Noofpeople;
	}

	public void setNoofpeople(String noofpeople) {
		Noofpeople.sendKeys(noofpeople);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getCardholdername() {
		return cardholdername;
	}

	public void setCardholdername(String cardholdername) {
		this.cardholdername.sendKeys(cardholdername);
	}

	public WebElement getDebitcardno() {
		return debitcardno;
	}

	public void setDebitcardno(String debitcardno) {
		this.debitcardno.sendKeys(debitcardno);
	}

	public WebElement getCVV() {
		return CVV;
	}

	public void setCVV(String cVV) {
		CVV.sendKeys(cVV);
	}

	public WebElement getExpirymonth() {
		return expirymonth;
	}

	public void setExpirymonth(String expirymonth) {
		this.expirymonth.sendKeys(expirymonth);
	}

	public WebElement getExpiryyear() {
		return expiryyear;
	}

	public void setExpiryyear(String expiryyear) {
		this.expiryyear.sendKeys(expiryyear);
	}

	public void Confirmbooking() {
		this.confirmbooking.click();
	}

}
